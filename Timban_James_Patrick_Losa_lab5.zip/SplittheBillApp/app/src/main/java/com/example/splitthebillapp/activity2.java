package com.example.splitthebillapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import java.text.DecimalFormat;

public class activity2 extends AppCompatActivity {
    int  all;
    double percent= .18, txtTip1, bills, txtPeople1, txtShare1, txtBill1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_activity2);
        final EditText bill= (EditText)findViewById(R.id.txtBill);
        final EditText people= (EditText)findViewById(R.id.txtPeople);
        Button costs= (Button)findViewById(R.id.button2);

        costs.setOnClickListener(new View.OnClickListener() {
            final TextView tip1= ((TextView)findViewById(R.id.txtTip));
            final TextView share= ((TextView)findViewById(R.id.txtShare));

            @Override
            public void onClick(View v) {
                all= Integer.parseInt(bill.getText().toString());
                txtPeople1= Integer.parseInt(people.getText().toString());
                txtTip1=  percent * all ;
                bills=txtTip1 + all;
                txtShare1= bills/txtPeople1;
                DecimalFormat currency = new DecimalFormat("Php###,###,###");

                tip1.setText("Your tip will be : " + currency.format(txtTip1));
                share.setText("You will pay " + currency.format(txtShare1) + "each");


            }
        });
    }

}